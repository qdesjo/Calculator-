console.clear();
let nbr = 0; //On dit que le nombre est = à 0
let nbraddition1 = 0; //On dit que le nombre est = à 0
let nbraddition2 = 0; //On dit que le nombre est = à 0

let nbrsoustraction1 = 0; //On dit que le nombre est = à 0
let nbrsoustraction2 = 0; //On dit que le nombre est = à 0

let nbrdivision1 = 0; //On dit que le nombre est = à 0
let nbrdivision2 = 0; //On dit que le nombre est = à 0

let nbrdivisioneuclidienne1 = 0; //On dit que le nombre est = à 0
let nbrdivisioneuclidienne2 = 0; //On dit que le nombre est = à 0

let nbrmultiplication1 = 0; //On dit que le nombre est = à 0
let nbrmultiplication2 = 0; //On dit que le nombre est = à 0

let nbrpuissance1 = 0; //On dit que le nombre est = à 0
let nbrpuissance2 = 0; //On dit que le nombre est = à 0

let nbrracinecarree1 = 0; //On dit que le nombre est = à 0

let nbrracinecubique1 = 0; //On dit que le nombre est = à 0

const nbr_0 = "0"; //On dit que le nombre est = à 0
const nbr_1 = "1"; //On dit que le nombre est = à 1
const nbr_2 = "2"; //On dit que le nombre est = à 2
const nbr_3 = "3"; //On dit que le nombre est = à 3
const nbr_4 = "4"; //On dit que le nombre est = à 4
const nbr_5 = "5"; //On dit que le nombre est = à 5
const nbr_6 = "6"; //On dit que le nombre est = à 6
const nbr_7 = "7"; //On dit que le nombre est = à 7
const nbr_8 = "8"; //On dit que le nombre est = à 8
const nbr_9 = "9"; //On dit que le nombre est = à 9

//Addition
addition.onclick = () => {
  //On dit que si on clique sur le bouton qui corespond à l'addition, on fait :
  nbraddition1 = nbr; //On dit que nbraddition1 prend la valeur de la var nbr
  nbr = 0; //On reset nbr à 0

  egal.onclick = () => {
    nbraddition2 = nbr; //On dit que nbraddition2 prend la valeur de la var nbr
    nbraddition1 = parseInt(nbraddition1); // On declare les strings stocké dans les variables précedentes comme étants des nombres
    nbraddition2 = parseInt(nbraddition2);

    let nbradditionfinal = nbraddition1 + nbraddition2; // On additionne les deux variables
    alert("Ton résultat est " + nbradditionfinal); //On donne le resultat
  };
};

//Soustraction
soustraction.onclick = () => {
  //On dit que si on clique sur le bouton qui corespond à la soustraction, on fait :
  nbrsoustraction1 = nbr; //On dit que nbraddition1 prend la valeur de la var nbr
  nbr = 0; //On reset nbr à 0

  egal.onclick = () => {
    nbrsoustraction2 = nbr; //On dit que nbraddition2 prend la valeur de la var nbr
    let nbrsoustractionfinal = nbrsoustraction1 - nbrsoustraction2; //On dit que nbraddition2 prend la valeur de la var nbr
    // On additionne les deux variables
    alert("Ton résultat est " + nbrsoustractionfinal); //On donne le resultat
  };
};

//Division
division.onclick = () => {
  //On dit que si on clique sur le bouton qui corespond à la soustraction, on fait :
  nbrdivision1 = nbr; //On dit que nbraddition1 prend la valeur de la var nbr
  nbr = 0; //On reset nbr à 0

  egal.onclick = () => {
    nbrdivision2 = nbr; //On dit que nbraddition2 prend la valeur de la var nbr
    let nbrdivisionfinal = nbrdivision1 / nbrdivision2; //On dit que nbraddition2 prend la valeur de la var nbr
    // On additionne les deux variables
    alert("Ton résultat est " + nbrdivisionfinal); //On donne le resultat
  };
};

//Division Euclidienne (pour savoir si x est diviseur de y)
divisioneuclidienne.onclick = () => {
  nbrdivisioneuclidienne1 = nbr; //On demande un nombre (qui sera divisié (dividende))
  nbr = 0;

  egal.onclick = () => {
    nbrdivisioneuclidienne1 = nbr; //On demande un diviseur

    let nbrdivisioneuclidienne3 =
      nbrdivisioneuclidienne1 % nbrdivisioneuclidienne1; //On fait la division euclidienne

    if (nbrdivisioneuclidienne3 > 0) {
      //On dit que si le reste de la division euclidienne n'est pas = à 0, alors on dit : Ton nombre n'est pas divisible par + le diviseur donné + le reste
      alert(
        "Ton nombre n'est pas divisible par " +
          nbrdivisioneuclidienne1 +
          " : Voici son reste " +
          nbrdivisioneuclidienne3
      );
    }
    if (nbrdivisioneuclidienne3 == 0) {
      //On dit que si le reste de la division euclidienne est = à 0, alors on dit : Ton nombre est pas divisible par + le diviseur donné
      alert("Ton nombre est  divisible par " + nbrdivisioneuclidienne1);
    }
  };
};

//Multiplication
multiplication.onclick = () => {
  //On dit que si on clique sur le bouton qui corespond à la multiplication, on fait :
  nbrmultiplication1 = nbr; //On dit que nbrmultiplication1 prend la valeur de la var nbr
  nbr = 0; //On reset nbr à 0

  egal.onclick = () => {
    nbrmultiplication2 = nbr; //On dit que nbrmultiplication2 prend la valeur de la var nbr
    let nbrdivisionfinal = nbrmultiplication1 * nbrmultiplication2; //On dit que nbrmultiplication2 prend la valeur de la var nbr
    // On multiplie les deux variables
    alert("Ton résultat est " + nbrdivisionfinal); //On donne le resultat
  };
};

//Puissance
puissance.onclick = () => {
  nbrpuissance1 = nbr; //On dit que nbrpuissance1 prend la valeur de la var nbr
  nbr = 0; //On reset nbr à 0

  egal.onclick = () => {
    nbrpuissance2 = nbr; //On dit que nbrpuissance2 prend la valeur de la var nbr
    let nbrpuissancefinal = Math.pow(nbrpuissance1, nbrpuissance2); //On dit que nbrpuissance2 prend la valeur de la var nbr
    // On fait le calcul entre les deux variables
    alert("Ton résultat est " + nbrpuissancefinal); //On donne le resultat
  };
};

//Racine carrée
racinecarree.onclick = () => {
  nbrracinecarree1 = nbr; //On dit que nbrracinecarree1 prend la valeur de la var nbr

  egal.onclick = () => {
    let nbrracinecarreefinal = Math.sqrt(nbrracinecarree1);
    // On fait le calcul entre les deux variables
    alert("Ton résultat est " + nbrracinecarreefinal); //On donne le resultat
  };
};

//Racine cubique
racinecubique.onclick = () => {
  //On dit que si on clique sur le bouton qui corespond à la puissance, on fait :
  nbrracinecubique1 = nbr; //On dit que nbrracinecubique1 prend la valeur de la var nbr

  egal.onclick = () => {
    let nbrracinecubiquefinal = Math.cbrt(nbrracinecubique1);
    // On fait le calcul entre les deux variables
    alert("Ton résultat est " + nbrracinecubiquefinal); //On donne le resultat
  };
};

AC.onclick = () => {
  nbr = 0; //On dit que le nombre est = à 0

  nbraddition1 = 0; //On dit que le nombre est = à 0
  nbraddition2 = 0; //On dit que le nombre est = à 0

  nbrsoustraction1 = 0; //On dit que le nombre est = à 0
  nbrsoustraction2 = 0; //On dit que le nombre est = à 0

  nbrdivision1 = 0; //On dit que le nombre est = à 0
  nbrdivision2 = 0; //On dit que le nombre est = à 0

  nbrdivisioneuclidienne1 = 0; //On dit que le nombre est = à 0
  nbrdivisioneuclidienne2 = 0; //On dit que le nombre est = à 0

  nbrmultiplication1 = 0; //On dit que le nombre est = à 0
  nbrmultiplication2 = 0; //On dit que le nombre est = à 0

  nbrpuissance1 = 0; //On dit que le nombre est = à 0
  nbrpuissance2 = 0; //On dit que le nombre est = à 0

  nbrracinecarree1 = 0; //On dit que le nombre est = à 0

  nbrracinecubique1 = 0; //On dit que le nombre est = à 0
};
afficher.onclick = () => {
  alert("La variable nombre est égale à : " + nbr);
};
nbr1.onclick = () => {
  nbr = nbr + nbr_1;
};
nbr2.onclick = () => {
  nbr = nbr + nbr_2;
};
nbr3.onclick = () => {
  nbr = nbr + nbr_3;
};
nbr4.onclick = () => {
  nbr = nbr + nbr_4;
};
nbr5.onclick = () => {
  nbr = nbr + nbr_5;
};
nbr6.onclick = () => {
  nbr = nbr + nbr_6;
};
nbr7.onclick = () => {
  nbr = nbr + nbr_7;
};
nbr8.onclick = () => {
  nbr = nbr + nbr_8;
};
nbr9.onclick = () => {
  nbr = nbr + nbr_9;
};
nbr0.onclick = () => {
  nbr = nbr + nbr_0;
};

document.write(nbr);
